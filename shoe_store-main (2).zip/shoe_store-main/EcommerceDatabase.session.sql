USE ecommerce_shoes;
CREATE DATABASE ecommerce_shoes;
CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique identifier for each cart item
    product_image VARCHAR(255) NOT NULL,      -- Path or URL of the product image
    product_price DECIMAL(10, 2) NOT NULL,    -- Price per product item
    product_size VARCHAR(10) NOT NULL,        -- Size of the product (e.g., S, M, L, etc.)
    product_quantity INT NOT NULL             -- Quantity of the product in the cart
);
CREATE TABLE customer_account (
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    PRIMARY KEY (username, email, password)
);
CREATE TABLE product_downshifter_sport_shoes (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique identifier for each cart item
    product_image VARCHAR(255) NOT NULL,      -- Path or URL of the product image
    product_price DECIMAL(10, 2) NOT NULL,    -- Price per product item
    product_size VARCHAR(10) NOT NULL,        -- Size of the product (e.g., S, M, L, etc.)
    product_quantity INT NOT NULL             -- Quantity of the product in the cart
);
CREATE TABLE product_lace_running_shoes (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique identifier for each cart item
    product_image VARCHAR(255) NOT NULL,      -- Path or URL of the product image
    product_price DECIMAL(10, 2) NOT NULL,    -- Price per product item
    product_size VARCHAR(10) NOT NULL,        -- Size of the product (e.g., S, M, L, etc.)
    product_quantity INT NOT NULL             -- Quantity of the product in the cart
);
CREATE TABLE product_flat_lace_fastening_shoes (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique identifier for each cart item
    product_image VARCHAR(255) NOT NULL,      -- Path or URL of the product image
    product_price DECIMAL(10, 2) NOT NULL,    -- Price per product item
    product_size VARCHAR(10) NOT NULL,        -- Size of the product (e.g., S, M, L, etc.)
    product_quantity INT NOT NULL             -- Quantity of the product in the cart
);
CREATE TABLE product_flat_heel_gray_shoes (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique identifier for each cart item
    product_image VARCHAR(255) NOT NULL,      -- Path or URL of the product image
    product_price DECIMAL(10, 2) NOT NULL,    -- Price per product item
    product_size VARCHAR(10) NOT NULL,        -- Size of the product (e.g., S, M, L, etc.)
    product_quantity INT NOT NULL             -- Quantity of the product in the cart
);
CREATE TABLE product_hrx_men_cotton_socks (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique identifier for each cart item
    product_image VARCHAR(255) NOT NULL,      -- Path or URL of the product image
    product_price DECIMAL(10, 2) NOT NULL,    -- Price per product item
    product_size VARCHAR(10) NOT NULL,        -- Size of the product (e.g., S, M, L, etc.)
    product_quantity INT NOT NULL             -- Quantity of the product in the cart
);
CREATE TABLE product_loafers_men_gray (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique identifier for each cart item
    product_image VARCHAR(255) NOT NULL,      -- Path or URL of the product image
    product_price DECIMAL(10, 2) NOT NULL,    -- Price per product item
    product_size VARCHAR(10) NOT NULL,        -- Size of the product (e.g., S, M, L, etc.)
    product_quantity INT NOT NULL             -- Quantity of the product in the cart
);
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    product_size VARCHAR(50) NOT NULL,
    product_quantity INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    username VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    cellphone VARCHAR(20) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

