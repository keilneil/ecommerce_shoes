<?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $conn = new mysqli('localhost', 'root', 'kiel12345678910', 'ecommerce_shoes');
        if ($conn->connect_error) {
            die('Database connection failed: ' . $conn->connect_error);
        }

        $productId = $_POST['product_id'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $size = $_POST['size'];
        $total = $_POST['total'];
        $address = $_POST['address'];
        $cellphone = $_POST['cellphone'];
        $paymentMethod = $_POST['payment_method'];

        // Insert order into the database
        $sql = "INSERT INTO orders (product_id, price, quantity, size, total_price, address, cellphone, payment_method) 
                VALUES ('$productId', '$price', '$quantity', '$size', '$total', '$address', '$cellphone', '$paymentMethod')";

        if ($conn->query($sql) === TRUE) {
            echo "Order placed successfully.";
        } else {
            echo "Error: " . $conn->error;
        }

        $conn->close();
    }
?>
