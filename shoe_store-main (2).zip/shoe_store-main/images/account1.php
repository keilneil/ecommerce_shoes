<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products - Redstore</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class="container">
        <!-- Navbar -->
        <div class="navbar">
            <div class="logo">
                <a href="index.html"><img src="images/logo.png" width="125px" alt="Redstore Logo"></a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="account1.php">Account</a></li>
                </ul>
            </nav>
            <a href="cart.html"><img src="images/cart.png" width="30px" height="30px" alt="Cart"></a>
            <img src="images/menu.png" class="menu-icon" onclick="menutoggle()" alt="Menu">
        </div>
    </div>

    <!-- Account Page -->
    <div class="account-page">
        <div class="container">
            <div class="row">
                <div class="col-2">
                    <img src="images/image1.png" width="100%" alt="Account Page Image">
                </div>
                <div class="col-2">
                    <div class="form-container">
                        <div class="form-btn">
                            <span onclick="login()">Login</span>
                            <span onclick="register()">Register</span>
                            <hr id="Indicator">
                        </div>
                        <!-- Login Form -->
                        <form action="account1.php" id="LoginForm" method="post">
                            <input type="text" placeholder="Username" name="Username-login" required>
                            <input type="password" placeholder="Password" name="Password-login" required>
                            <button type="submit" class="btn" name="btn-login">Login</button>
                            <div id="forgot-password-id" style="cursor: pointer; color: #ff523b; margin-top: 10px;">Forgot Password?</div>
                        </form>
                        <!-- Register Form -->
                        <form id="RegForm" method="post">
                            <input type="text" placeholder="Username" name="username-register" required>
                            <input type="email" placeholder="Email" name="email-register" required>
                            <input type="password" placeholder="Password" name="password-register" required>
                            <button type="submit" class="btn" name="register-btn">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <?php 

$servername = "localhost";
$dbuser = "root";
$dbpass = "kiel12345678910";
$dbname = "Shoe_store_ecommerce";

$conn = new mysqli($servername , $dbuser, $dbpass, $dbname);

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register-btn'])){

if($conn->connect_error){
    $conn->connect_error;

}else{
    echo "Connected";

    $Username = $_POST['username-register'];
    $Email = $_POST['email-register'];
    $Password = $_POST['password-register'];

    $sql = "INSERT INTO registerform (Username,Email,Password)VALUES(?,?,?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $Username,$Email,$Password);

    if($stmt->execute()){
        
    }else{
        $stmt->error;
    }
    exit();


}
}
$conn->close();
?>

<?php 

$servername1 = "localhost";
$dbuser1 = "root";
$dbpass1 = "kiel12345678910";
$dbname1 = "Shoe_store_ecommerce";

$conn1 = new mysqli($servername1 , $dbuser1, $dbpass1, $dbname1);

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['btn-login'])){

if($conn1->connect_error){
    $conn1->connect_error;

}else{
    echo "Connected";

    
    $Usernamelogin = $_POST['Username-login'];
    $Passwordlogin  = $_POST['Password-login'];

    $sql1 = "SELECT * FROM registerform WHERE   Username=?";

    $stmt1 = $conn1->prepare($sql1);
    $stmt1->bind_param("s", $Username);

    if($stmt1->execute()){
        $result = $stmt1->get_result();

        if($result->num_rows>0){
            $user = $result->fetch_assoc();
             if($Username == $user['Password-login']){
                header("Location:newfile.php");
             }else{
              
            
             }
        }
        
    }else{
        $stmt1->error;
    }
    exit();


}
}
$conn1->close();
?>

    <?php


$servername = "loaclhost";
$dbuser = "root";
$dbpassword = "kiel12345678910";


?>
    <!-- Footer -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and iOS mobile phones.</p>
                    <div class="app-logo">
                        <img src="images/play-store.png" alt="Play Store">
                        <img src="images/app-store.png" alt="App Store">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="images/logo-white.png" alt="Redstore Logo">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li>Coupons</li>
                        <li>Blog Post</li>
                        <li>Return Policy</li>
                        <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow Us</h3>
                    <ul>
                        <li>Facebook</li>
                        <li>Twitter</li>
                        <li>Instagram</li>
                        <li>YouTube</li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="copyright">Copyright 2021 - Apurba Kr. Pramanik</p>
        </div>
    </div>

<!-- Forgot Password Popup -->
<div id="popupForgotPassword" class="popup-forgot-password">
        <div class="popup-content">
            <span class="close-btn" id="closePopup">&times;</span>
            <h5>Forgot Password</h5>
            <p>Please enter your email to reset your password.</p>
            <form method="post">
            <input type="email" placeholder="Enter your email" name="username-forgot" style="width: 100%; padding: 10px; margin: 10px 0;" required>
            <button class="btn" name="forgot-submit-button">Submit</button>
            </form>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // Menu Toggle
        const MenuItems = document.getElementById("MenuItems");
        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            if (MenuItems.style.maxHeight === "0px") {
                MenuItems.style.maxHeight = "200px";
            } else {
                MenuItems.style.maxHeight = "0px";
            }
        }

        // Form Toggle
        const LoginForm = document.getElementById("LoginForm");
        const RegForm = document.getElementById("RegForm");
        const Indicator = document.getElementById("Indicator");

        function register() {
            RegForm.style.transform = "translateX(0px)";
            LoginForm.style.transform = "translateX(0px)";
            Indicator.style.transform = "translateX(100px)";
        }

        function login() {
            RegForm.style.transform = "translateX(300px)";
            LoginForm.style.transform = "translateX(300px)";
            Indicator.style.transform = "translateX(0px)";
        }

        // Forgot Password Popup
        const forgotPasswordLink = document.getElementById('forgot-password-id');
        const popupForgotPassword = document.getElementById('popupForgotPassword');
        const closePopupBtn = document.getElementById('closePopup');

        forgotPasswordLink.addEventListener('click', () => {
            popupForgotPassword.style.display = 'flex';
        });

        closePopupBtn.addEventListener('click', () => {
            popupForgotPassword.style.display = 'none';
        });

        window.addEventListener('click', (e) => {
            if (e.target === popupForgotPassword) {
                popupForgotPassword.style.display = 'none';
            }
        });
    </script>

    <style>
        /* Popup Wrapper */
        .popup-forgot-password {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        /* Popup Content */
        .popup-content {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            width: 400px;
            position: relative;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        /* Close Button */
        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 18px;
            cursor: pointer;
            color: #333;
        }

        /* Button Styling */
        .btn {
            background: #ff523b;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        .btn:hover {
            background: #ff6f61;
        }
    </style>
</body>

</html>
