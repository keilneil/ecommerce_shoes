<?php 
	$connsn = "localhost";
	$connun = "root";
	$connpass = "kiel12345678910";
	$conndbn = "ecommerce_shoes";
	$connport = "3306";
	$conn = mysqli_connect($connsn,$connun,$connpass,$conndbn,$connport);
	
 ?>

 