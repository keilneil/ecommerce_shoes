<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="cart-container">
        <?php
        $conn = new mysqli('localhost', 'root', 'kiel12345678910', 'ecommerce_shoes');
        if ($conn->connect_error) {
            die('Database connection failed: ' . $conn->connect_error);
        }

        $sql = "SELECT * FROM flat_heel_gray_shoes";
        $result = $conn->query($sql);

        if ($result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
        <div class="cart-item">
            <img src="<?= htmlspecialchars($row['product_image']) ?>" alt="Product Image" class="product-image">
            <div class="cart-item-info">
                <p><strong>Product ID:</strong> <?= htmlspecialchars($row['id']) ?></p>
                <p><strong>Price:</strong> $<?= htmlspecialchars($row['product_price']) ?></p>
                <p><strong>Size:</strong> <?= htmlspecialchars($row['product_size']) ?></p>
                <p><strong>Quantity:</strong> <?= htmlspecialchars($row['product_quantity']) ?></p>
            </div>
            <div class="cart-item-actions">
               
            <button class="edit-btn" onclick="editCartItem(<?= $row['id'] ?>, <?= $row['product_quantity'] ?>, '<?= $row['product_size'] ?>')">Edit</button>
                <button class="buy-btn" onclick="showUsernameModal(<?= $row['id'] ?>)">Buy Now</button>
            </div>
        </div>
        
        
        <?php
            endwhile;
        else:
        ?>
        <p>No items in the cart.</p>
        <?php
        endif;

        $conn->close();
        ?>
    </div>

    <!-- Edit Modal -->
    

    <!-- Edit Modal -->

    <div id="editModal" style="display: none">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>Edit Product</h2>
        <form id="editForm">
            <div class="form-group">
                <label for="editId">ID</label>
                <input type="text" id="editId" name="id" readonly>
            </div>
            <div class="form-group">
                <label for="editQuantity">Quantity</label>
                <input type="number" id="editQuantity" name="quantity" required>
            </div>
            <div class="form-group">
                <label for="editSize">Size</label>
                <select id="editSize" name="size" required>
                    <option value="">Select a size</option>
                    <option value="small">Small</option>
                    <option value="medium">Medium</option>
                    <option value="large">Large</option>
                 
                </select>
            </div>
            <button type="submit" class="btn">Save Changes</button>
        </form>
    </div>
</div>

   
      
    
    <div id="usernameModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeUsernameModal()">&times;</span>
        <h3>Enter Username</h3>
        <input type="text" id="usernameInput" placeholder="Enter your username" />
        <button onclick="verifyUsername()">Submit</button>
    </div>
</div>

<!-- Confirmation Modal -->
<div id="confirmationModal" class="modal">
    <div class="modal-content">
        <h3>Order Confirmation</h3>
        <p id="product-size"></p>
        <p id="product-quantity"></p>
        <p id="total-price"></p>
        <input type="text" id="address" placeholder="Enter address" />
        <input type="text" id="cellphone" placeholder="Enter cellphone" />
        <select id="payment-method">
            <option value="">Select Payment Method</option>
            <option value="Credit Card">Credit Card</option>
            <option value="PayPal">PayPal</option>
        </select>
        <button onclick="placeOrder()">Place Order</button>
        <button onclick="closeConfirmationModal()">Cancel</button>
    </div>
</div>

<!-- Hidden Input for Product ID -->
<input type="hidden" id="order-product-id" value="1" />
    <style>
       
/* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
    line-height: 1.6;
}

/* Cart Container */
.cart-container {
    width: 90%;
    max-width: 800px;
    margin: 20px auto;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 20px;
    max-height: 400px;
    overflow-y: auto;
}

.cart-item {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

.cart-item:last-child {
    border-bottom: none;
}

.product-image {
    width: 80px;
    height: 80px;
    object-fit: cover;
    margin-right: 15px;
    border-radius: 5px;
}

.cart-item-info {
    flex: 1;
}

.cart-item-info p {
    margin: 5px 0;
}

.cart-item-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.edit-btn,
.buy-btn {
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.edit-btn {
    background-color: #007bff;
    color: white;
}

.edit-btn:hover {
    background-color: #0056b3;
}

.buy-btn {
    background-color: #28a745;
    color: white;
}

.buy-btn:hover {
    background-color: #218838;
}

.no-items {
    text-align: center;
    font-size: 16px;
    color: #666;
}

/* Modal Styling */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.modal-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    width: 90%;
    max-width: 400px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    text-align: center;
    position: relative;
}

.modal-content h2,
.modal-content h3 {
    margin-bottom: 20px;
    color: #333;
}

.modal-content p {
    margin: 10px 0;
    font-size: 16px;
    color: #555;
}

.modal-content input[type="text"],
.modal-content input[type="number"],
.modal-content select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

.modal-content button {
    padding: 10px 20px;
    margin: 10px 5px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.modal-content button:first-of-type {
    background-color: #4CAF50;
    color: #fff;
}

.modal-content button:last-of-type {
    background-color: #f44336;
    color: #fff;
}

.modal-content button:hover {
    opacity: 0.9;
}

.close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px;
    font-weight: bold;
    color: #aaa;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
}

/* Responsive Design */
@media (max-width: 480px) {
    .modal-content {
        width: 95%;
        padding: 15px;
    }

    .modal-content button {
        width: 100%;
        margin: 5px 0;
    }
}


.editModal{
    display: none;
}

/* Modal Background */
#editModal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

/* Modal Content */
.modal-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    width: 90%;
    max-width: 400px;
    position: relative;
    text-align: center;
}

/* Close Button */
.modal-content .close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 24px;
    font-weight: bold;
    color: #333;
    cursor: pointer;
    transition: color 0.3s;
}

.modal-content .close:hover {
    color: #ff0000;
}

/* Form Group */
.form-group {
    margin-bottom: 15px;
    text-align: left;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

/* Submit Button */
.btn {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.btn:hover {
    background-color: #0056b3;
}

        
    </style>

    <script>


// Function to handle editing cart item
function editCartItem(id, quantity, size) {
    document.getElementById('editId').value = id;
    document.getElementById('editQuantity').value = quantity;
    document.getElementById('editSize').value = size;
    document.getElementById('editModal').style.display = 'block';
}

// Close edit modal
function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Handle edit form submission
document.getElementById('editForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const id = document.getElementById('editId').value;
    const quantity = document.getElementById('editQuantity').value;
    const size = document.getElementById('editSize').value;

    try {
        const response = await fetch('edit_product_flat_heel_gray_shoes.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${encodeURIComponent(id)}&quantity=${encodeURIComponent(quantity)}&size=${encodeURIComponent(size)}`,
        });

        const result = await response.json();

        if (result.success) {
            Swal.fire('Success', result.message, 'success').then(() => {
                closeModal();
                location.reload();
            });
        } else {
            Swal.fire('Error', result.message, 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire('Error', 'An unexpected error occurred.', 'error');
    }
});

// Show username modal with product ID
function showUsernameModal(productId) {
    document.getElementById('usernameModal').style.display = 'flex';
    document.getElementById('order-product-id').value = productId;
}

// Close username modal
function closeUsernameModal() {
    document.getElementById('usernameModal').style.display = 'none';
}

// Verify username
function verifyUsername() {
    const username = document.getElementById('usernameInput').value;

    if (!username.trim()) {
        Swal.fire('Error', 'Username is required.', 'error');
        return;
    }

    fetch('confirmation.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username)}`,
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                Swal.fire('Success', data.message, 'success').then(() => {
                    closeUsernameModal();
                    fetchProductDetails();
                });
            } else {
                Swal.fire('Error', data.message, 'error');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            Swal.fire('Error', 'An error occurred while verifying the username.', 'error');
        });
}

// Fetch product details
function fetchProductDetails() {
    const productId = document.getElementById('order-product-id').value;

    console.log("Fetching product details for Product ID:", productId);

    fetch('edit_flat_heel_gray_shoes.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${encodeURIComponent(productId)}`,
    })
        .then((response) => response.json())
        .then((data) => {
            console.log("Server Response:", data);

            if (data.success) {
                // Update the modal with product details
                document.getElementById('product-size').textContent = `Size: ${data.data.size}`;
                document.getElementById('product-quantity').textContent = `Quantity: ${data.data.quantity}`;
                const totalPrice = (data.data.price && data.data.quantity) 
                    ? (data.data.price * data.data.quantity).toFixed(2) 
                    : 'N/A';
                document.getElementById('total-price').textContent = `Total: $${totalPrice}`;
                document.getElementById('confirmationModal').style.display = 'block';
            } else {
                Swal.fire('Error', 'Failed to fetch product details: ' + data.message, 'error');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            Swal.fire('Error', 'An error occurred while fetching product details.', 'error');
        });
}

// Close confirmation modal
function closeConfirmationModal() {
    document.getElementById('confirmationModal').style.display = 'none';
}


// Place order
function placeOrder() {
    const address = document.getElementById('address').value;
    const cellphone = document.getElementById('cellphone').value;
    const paymentMethod = document.getElementById('payment-method').value;
    const productId = document.getElementById('order-product-id').value;

    if (!address || !cellphone || !paymentMethod) {
        Swal.fire('Error', 'Please fill all the required fields.', 'error');
        return;
    }

    fetch('placeOrder.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `productId=${encodeURIComponent(productId)}&address=${encodeURIComponent(address)}&cellphone=${encodeURIComponent(cellphone)}&paymentMethod=${encodeURIComponent(paymentMethod)}`,
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                Swal.fire('Success', 'Order placed successfully!', 'success').then(() => {
                    closeConfirmationModal();
                });
            } else {
                Swal.fire('Error', 'Failed to place order: ' + data.message, 'error');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            Swal.fire('Error', 'An error occurred while placing the order.', 'error');
        });
}

    </script>
</body>

</html>


