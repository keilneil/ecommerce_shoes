<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width-device-width, initial-scale=1.0">
        <title>Redstore | Ecommerce website</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
        <!--added a cdn link by searching font awesome4 cdn and getting this link from https://www.bootstrapcdn.com/fontawesome/ this url*/-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    </head>
    <body>
        <div class ="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="index.php"><img src="images/logo.png" width="125px"></a>
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="index.php">Home</a></li>
                         <li><a href="account.php">Products</a></li>
                         <li><a href="about_us.php">About</a></li>
                         <li><a href="contact_us.php">Contact</a></li>
                         <li><a href="account.php">Account</a></li>

                    </ul>
                </nav>
                <a href=""><img src="images/cart.png" width="30px" height="30px"></a>
              
                <img src="images/menu.png" class="menu-icon" onClick="menutoggle()" >
            </div>
            <div class="row">
                <div class="col-2">
                    <h1>Give your Workout <br>A New Style!</h1>
                    <p>Success isn't always about greatness. It's about consistency. Consistent<br>hard work gains success. Greatness will come.</p>
                    <a href="account.php" class="btn">Explore Now &#8594;</a>
                </div>
                <div class="col-2">
                    <img src="images/image1.png">
                </div>
            </div>
        </div>
    </div>
        
        <!------------------------------ featured categories------------------------------>
        <div class="categories">
            <div class="small-container">
                <div class="row">
                <div class="col-3">
                    <img src="images/category-1.jpg">
                </div>
                <div class="col-3">
                    <img src="images/category-2.jpg">
                </div>
                <div class="col-3">
                    <img src="images/category-3 (2).jpg">
                </div>
            </div>
            </div>
        </div>
        
        <!------------------------------ featured Products------------------------------>
        <div class="small-container">
            <h2 class="title" >Featured Products</h2>
            <div class="row">
                <div class="Downshifter">
                <div class="col-4 animate">
                    <a href="account.php">
                        <img src="images/product-11.jpg" alt="Downshifter Sports Shoes" class="shoe-image" > 

                    </a>
                    <h4>Downshifter Sports Shoes</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>$50.00</p>
                </div>
            </div>
           
                <!-- Repeat for other products -->
            </div>
            <div class="lace-running-shoes">
            <div class="col-4 animate">
                <a href="account.php">
                    <img src="images/product-2.jpg" alt="Lace-Up Running Shoes" class="shoe-image">
                </a>
                <h4>Lace-Up Running Shoes</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>$49.00</p>
            </div>
        </div>
           
        <div class="flat-lace-fastening-shoes">
                    <div class="col-4 animate">
                        <a href="account.php"><img src="images/product-10.jpg"></a>
                        <h4>Flat Lace-Fastening Shoes</h4>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$48.00</p>
                    </div>  
                </div>
            </div>
            <br>
            <br>

            
             <h2 class="title" >Latest Products</h2>
                <div class="row">
                    <div class="col-4 animate">
                        <a href="account.php"><img src="images/product-5.jpg"></a>
                        <h4>Flat Heel gray hoes</h4>
                        <div class="rating">
                            <!--(before this added awesome4 cdn font link to the head)added a cdn link by searching font awesome4 icon and from the site  search the star entering the first option and getting a link of this fa-star*-->
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-half-o" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$50.00</p>
                    </div>
                    
                    <div class="col-4 animate">
                        <a href="account.php"><img src="images/product-7.jpg"></a>
                        <h4>HRX Men's cotton socks</h4>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$09.00</p>
                    </div>
                    <div class="col-4">
                        <a href="account.php"><img src="images/product-2.jpg"></a>
                        <h4>Lace-Up Running Shoes</h4>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$35.00</p>
                    </div>  
                </div>
            <!--new row for the latest product-->
                <div class="row">
                    <div class="col-4">
                        <a href="account.php"><img src="images/product-7.jpg"></a>
                        <h4>HRX cotton socks</h4>
                        <div class="rating">
                            <!--(before this added awesome4 cdn font link to the head)added a cdn link by searching font awesome4 icon and from the site  search the star entering the first option and getting a link of this fa-star*-->
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-half-o" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$9.00</p>
                    </div>
                    <div class="col-4 animate">
                        <a href="account.php"><img src="images/product-10.jpg"></a>
                        <h4>Flat Lace-Fastening Shoes</h4>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-half-o" ></i>
                        </div>
                        <p>$48.00</p>
                    </div>
                    <div class="col-4">
                        <a href="account.php"><img src="images/product-11.jpg"></a>
                        <h4>Loafers Men (Gray)</h4>
                        <div class="rating">
                            <i class="fa fa-star-o" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$52.00</p>
                    </div>
                   
                    
                </div>
            </div>
        
        <!--------------------------   offer   --------------------------------->
        <div class="offer">
            <div class="small-container">
                <div class="row">
                    <div class="col-2">
                        <img src="images/image1.png" class="offer-img">
                    </div>
                    <div class="col-2">
                        <p>Exclusively Available on RedStore</p>
                        <h1>Sports Shoes</h1>
                        <small> Buy latest collections of sports shoes online on Redstore at best prices from top brands such as Adidas, Nike, Puma, Asics, and Sparx at your leisure at best prices. </small><br>
                        <a href="account.php" class="btn">Buy Now &#8594;</a>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        <!------------------------------Testimonial---------------------------------->
        <div class="testimonial">
            <div class="small-container">
                <div class="row">
                    <div class="col-3">
                        <i class="fa fa-quote-left" ></i>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                        <div class="rating"> 
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <img src="images/user-1.png">
                        <h3>Sean Parkar</h3>
                    </div>
                    <div class="col-3">
                        <i class="fa fa-quote-left" ></i>
                        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <img src="images/user-2.png">
                        <h3>Mike Smith</h3>
                    </div>
                    <div class="col-3">
                        <i class="fa fa-quote-left" ></i>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
                        <div class="rating"> 
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <img src="images/user-3.png">
                        <h3>Mabel Joe</h3>
                    </div>
                </div>
            </div>
        </div>
        
        <!----------------------------------Brands------------------------------------>
        <div class="brands">
            <div class="small-container">
                <div class="row">
                    <div class="col-5">
                        <img src="images/logo-godrej.png" alt="">
                    </div>
                    <div class="col-5">
                        <img src="images/logo-oppo.png" alt="">
                    </div>
                    <div class="col-5">
                        <img src="images/logo-coca-cola.png" alt="">
                    </div>
                    <div class="col-5">
                        <img src="images/logo-paypal.png" alt="">
                    </div>
                    <div class="col-5">
                        <img src="images/logo-philips.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        
        
        <!----------------------------------footer------------------------------------->
        <div class ="footer">
        <div class="container">
            
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and ios mobile phone.</p>
                    <div class="app-logo">
                        <img src="images/play-store.png" alt="">
                        <img src="images/app-store.png" alt="">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="images/logo-white.png">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                   <ul>
                       <li>Coupons</li>
                       <li>Blog Post</li>
                       <li>Return Policy</li>
                       <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow us</h3>
                   <ul>
                       <li>Facebook</li>
                       <li>Twitter</li>
                       <li>Instagram</li>
                       <li>Youtube</li>
                    </ul>
                </div>
                
            </div>
            
            <hr><!--horizontal line-->
            <p class="copyright">Copyright 2021 - Apurba Kr. Pramanik</p>
            
        </div>
    </div>
        
        
        <!-----------------------------------js for toggle menu----------------------------------------------->
        <script>
            var menuItems=document.getElementById("MenuItems");
            
            MenuItems.style.maxHeight="0px";
            function menutoggle(){
                if(MenuItems.style.maxHeight == "0px"){
                    MenuItems.style.maxHeight="200px";
                }
                else{
                    MenuItems.style.maxHeight="0px";
                }
            }
        </script>
    </body>
</html>
<style>
   /* General styles */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    overflow-x: hidden; /* Prevents horizontal scrolling */
}

.container, .small-container {
    max-width: 1200px;
    margin: auto;
    padding: 0 40px;
    overflow: hidden;
   
}

.row {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-bottom: 30px;
    
}

.col-4 {
    flex: 1;
    max-width: 23%;
    text-align: center;
    margin: 10px 0;
}

.col-4 img {
    width: 100%;
    max-width: 300px; /* Restricts max size */
    height: auto;
    margin: 0 auto;
    display: block;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.col-4 img:hover {
    transform: scale(1.1);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
}

.row .animate {
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s ease-out;
}

.row .animate.slide-in {
    opacity: 1;
    transform: translateY(0);
}

/* Featured categories section */
.categories .col-3 {
    flex: 1;
    max-width: 30%;
    margin: 10px;
    text-align: center;
}

.categories img {
    width: 100%;
    max-width: 300px;
    height: auto;
    display: block;
    margin: 0 auto;
}

/* Offer section */
.offer {
    background: #f8f8f8;
    padding: 50px 20px;
    text-align: center;
}

.offer .row {
    flex-direction: row;
    align-items: center;
    justify-content: center;
    text-align: left;
}

.offer .offer-img {
    max-width: 400px;
    width: 100%;
    height: auto;
}

/* Testimonials */
.testimonial .col-3 {
    flex: 1;
    max-width: 30%;
    margin: 10px;
    text-align: center;
    padding: 20px;
    background: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.testimonial .rating i {
    color: #ff523b;
}

/* Brands section */
.brands .col-5 {
    flex: 1;
    max-width: 20%;
    margin: 10px;
    text-align: center;
}

.brands img {
    max-width: 150px;
    width: 100%;
    height: auto;
    margin: 0 auto;
}

/* Footer */
.footer {
    background: #333;
    color: #fff;
    padding: 40px 20px;
}

.footer h3 {
    margin-bottom: 20px;
}

.footer ul {
    list-style: none;
    padding: 0;
}

.footer ul li {
    margin: 10px 0;
    color: #bbb;
}

.footer ul li:hover {
    color: #fff;
    cursor: pointer;
}

.footer-col-1, .footer-col-2, .footer-col-3, .footer-col-4 {
    flex: 1;
    margin: 20px 0;
    max-width: 25%;
}

/* Utility classes */
.text-center {
    text-align: center;
}

.hidden {
    display: none;
}

/* Responsiveness */
@media (max-width: 768px) {
    .row, .footer .row {
        flex-direction: column;
        text-align: center;
    }

    .col-4, .categories .col-3, .testimonial .col-3, .brands .col-5 {
        max-width: 100%;
    }

    .navbar ul {
        max-height: 200px;
    }

    .offer .row {
        flex-direction: column;
        text-align: center;
    }
}

@media (max-width: 480px) {
    .col-4 img {
        max-width: 250px;
    }

    .footer {
        text-align: center;
    }

    .footer ul {
        display: inline-block;
    }
}

.lace-running-shoes{
      margin-top: -40%;
      margin-left: 30%;
      text-align: center;
}
.lace-flastening-shoes{
    margin-top: -30%;
      margin-left: 50%;
      text-align: center;
}
.flat-lace-fastening-shoes{
    margin-top: -30%;
      margin-left: 70%;
      text-align: center;
}


</style>

<script>
    document.addEventListener("DOMContentLoaded", () => {
    const elements = document.querySelectorAll(".animate");

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("slide-in");
            }
        });
    });

    elements.forEach((el) => observer.observe(el));
});



</script>