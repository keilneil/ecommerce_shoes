<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: account.php");
    exit();
}

require 'dat6abase-ecommerce/ecommerce_sql.php';  // Include database connection

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM orders WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

echo "<h1>Your Orders</h1>";

if ($result->num_rows > 0) {
    while ($order = $result->fetch_assoc()) {
        echo "<p>Order ID: " . $order['id'] . " - Product: " . $order['product_name'] . " - Quantity: " . $order['quantity'] . "</p>";
    }
} else {
    echo "<p>No orders found.</p>";
}

$conn->close();
?>
