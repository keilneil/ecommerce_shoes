<?php
header('Content-Type: application/json');

// Database connection
require 'dat6abase-ecommerce/ecommerce_sql.php';

// Get POST data
$product_image = $_POST['product_image'] ?? '';
$product_base_price = $_POST['product_base_price'] ?? '';
$product_size = $_POST['product_size'] ?? '';
$product_quantity = $_POST['product_quantity'] ?? '';

// Validate input data
if (!$product_image || !$product_base_price || !$product_size || !$product_quantity) {
    echo json_encode(['success' => false, 'message' => 'Invalid input data']);
    exit;
}

// Sanitize input data to prevent SQL injection
$product_image = $conn->real_escape_string($product_image);
$product_base_price = $conn->real_escape_string($product_base_price);
$product_size = $conn->real_escape_string($product_size);
$product_quantity = (int)$product_quantity;  // Ensure quantity is an integer

// Insert into 'cart' table
$stmt1 = $conn->prepare("INSERT INTO cart (product_image, product_price, product_size, product_quantity) 
                         VALUES (?, ?, ?, ?)");
$stmt1->bind_param("sssi", $product_image, $product_base_price, $product_size, $product_quantity);

// Insert into 'product_lace_running_shoes' table
$stmt2 = $conn->prepare("INSERT INTO product_lace_running_shoes (product_image, product_price, product_size, product_quantity) 
                         VALUES (?, ?, ?, ?)");
$stmt2->bind_param("sssi", $product_image, $product_base_price, $product_size, $product_quantity);

// Execute both statements and check for errors
if ($stmt1->execute() && $stmt2->execute()) {
    echo json_encode(['success' => true, 'message' => 'Product added to cart and product table successfully']);
} else {
    $error = $stmt1->error ?: $stmt2->error; // Get the first error if any
    echo json_encode(['success' => false, 'message' => 'Error: ' . $error]);
}

// Close the statements and the database connection
$stmt1->close();
$stmt2->close();
$conn->close();
?>
