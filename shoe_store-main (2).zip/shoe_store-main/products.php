<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width-device-width, initial-scale=1.0">
        <title>All Products - Redstore</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
        <!--added a cdn link by searching font awesome4 cdn and getting this link from https://www.bootstrapcdn.com/fontawesome/ this url*/-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    </head>
    <body>
        <!--<div class ="header">-->
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="index.html"><img src="images/logo.png" width="125px"></a>
                </div>
               <nav>
                    <ul id="MenuItems">
                    <li><a href="index.php">Home</a></li>
                         <li><a href="account.php">Products</a></li>
                         <li><a href="about_us.php">About</a></li>
                         <li><a href="contact_us.php">Contact</a></li>
                         <li><a href="account.php">Account</a></li>
                    </ul>
                </nav>
                <a href="add_to_cart_show_data.php"><img src="images/cart.png" width="30px" height="30px"></a>
                <img src="images/menu.png" class="menu-icon" onClick="menutoggle()" >
            </div>
           
        </div>
    <!--</div>-->
    
        
        <!------------------------------ Products------------------------------>
        <div class="small-container">
            <div class="row row-2">
                <h2>All Products</h2>
                <select id="sortOptions" onchange="sortProducts()">
                <option value="default">Default sorting</option>
                <option value="price">Sort by price</option>
                <option value="popularity">Sort by popularity</option>
                <option value="sale">Sort by sale</option>
            </select>

            </div>
            
            
            <!--<h2 class="title" >Featured Products</h2>-->
            <div class="row" id="productGrid">
            <div class="col-4" data-price="50" data-popularity="4" data-sale="100">
                        <a href="products-detail-downshifter-sport-shoes.php"><img src="images/product-11.jpg"></a>
                        <a href="products-detail-downshifter-sport-shoes.php"><h4>Downshifter Sports Shoes</h4></a>
                        <div class="rating">
                            
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-half-o" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$50.00</p>
                    </div>
                    <div class="col-4" data-price="49" data-popularity="5" data-sale="200">

                        <a href="lace-up-running-shoes.php"><img src="images/product-2.jpg"></a>
                        <a href="lace-up-running-shoes.php"><h4>Lace-Up Running Shoes</h4></a>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-half-o" ></i>
                        </div>
                        <p>$49.00</p>
                    </div>
                   
                    <div class="col-4" data-price="48" data-popularity="3" data-sale="150">

                        <a href="flat-lace-fastening-shoes.php"><img src="images/product-10.jpg"></a>
                        <h4>Flat Lace-Fastening Shoes</h4>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$48.00</p>
                    </div>  
            
            
            <!-------------- new row----------------->
            
           
            <div class="col-4" data-price="50" data-popularity="4" data-sale="100">
                        <a href="flat-heel-gray-shoes.php"><img src="images/product-5.jpg"></a>
                        <h4>Flat Heel gray hoes</h4>
                        <div class="rating">
                            
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-half-o" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$50.00</p>
                    </div>
                    
                    <div class="col-4" data-price="9" data-popularity="4" data-sale="09">
                        <a href="hrx-men-cottons-socks.php"><img src="images/product-7.jpg"></a>
                        <h4>HRX Men's cotton socks</h4>
                        <div class="rating">
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$9.00</p>
                    </div>
                   
               
            <!--new row for the latest product-->
                
            <div class="col-4" data-price="52" data-popularity="1" data-sale="52">
                        <a href="Loafers-Men.php"><img src="images/product-11.jpg"></a>
                        <h4>Loafers Men (Gray)</h4>
                        <div class="rating">
                            <i class="fa fa-star-o" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star" ></i>
                            <i class="fa fa-star-o" ></i>
                        </div>
                        <p>$52.00</p>
                    </div>
                    
                </div>
            
                </div>
        </div>
        
        
        <!----------------------------------footer------------------------------------->
        <div class ="footer">
        <div class="container">
            
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and ios mobile phone.</p>
                    <div class="app-logo">
                        <img src="images/play-store.png" alt="">
                        <img src="images/app-store.png" alt="">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="images/logo-white.png">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                   <ul>
                       <li>Coupons</li>
                       <li>Blog Post</li>
                       <li>Return Policy</li>
                       <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow us</h3>
                   <ul>
                       <li>Facebook</li>
                       <li>Twitter</li>
                       <li>Instagram</li>
                       <li>Youtube</li>
                    </ul>
                </div>
                
            </div>
            
            <hr><!--horizontal line-->
            <p class="copyright">Copyright 2021 - Apurba Kr. Pramanik</p>
            
        </div>
    </div>
        
        
        <!-----------------------------------js for toggle menu----------------------------------------------->
        <script>
            var menuItems=document.getElementById("MenuItems");
            
            MenuItems.style.maxHeight="0px";
            function menutoggle(){
                if(MenuItems.style.maxHeight == "0px"){
                    MenuItems.style.maxHeight="200px";
                }
                else{
                    MenuItems.style.maxHeight="0px";
                }
            }
        </script>
    </body>
    <style>
       
/* Footer */
.footer {
    background: #000;
    color: #fff;
    padding: 30px 0;
    text-align: center;
}

.footer-col-1, .footer-col-2, .footer-col-3, .footer-col-4 {
    margin-bottom: 20px;
}

.footer h3 {
    font-size: 16px;
    margin-bottom: 10px;
}

.footer ul {
    list-style: none;
}

.footer ul li {
    margin-bottom: 5px;
}

.footer ul li a {
    text-decoration: none;
    color: #fff;
    transition: color 0.3s;
}

.footer ul li a:hover {
    color: #ff523b;
}

.footer img {
    max-width: 100%;
    height: auto;
}

.footer .app-logo img {
    max-width: 120px;
    margin: 10px 5px 0 0;
    display: inline-block;
}

.copyright {
    margin-top: 20px;
    font-size: 14px;
}

/* Responsive Design */
@media (max-width: 768px) {
    .navbar nav {
        display: none;
    }

    .menu-icon {
        display: block;
    }

    .col-4 {
        flex: 1 1 100%;
    }
}
.col-4 img {
    width: 50%;
    height: 50%;
    max-width: 200px; /* Adjust this value as needed */
    max-height: 220px; /* Added to control height */
    object-fit: cover; /* Ensures images fit nicely without distortion */
    transition: transform 0.3s;
}

.menu-icon{
    width: 28px;
    margin-left: 20px;  
    display:none;
}
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    font-family: 'Poppins', sans-serif;
}
/*nav maenu on the left as a unordered list*/
.navbar{
    display:flex;
    align-items: center;
    padding:20px;
}
/*nav maenu on the right as a unordered list*/
nav{
    flex: 1;
    text-align: right;
}
/*nav maenu on the right as a list but without bullet*/
nav ul{
    display: inline-block;
    list-style-type: none;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each with underline*/
nav ul li{
    display: inline-block;
    margin-right: 50px;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each without underline*/
a{
    text-decoration: none;
    color: #555;
}
p{
    color: #555;
}
.container{
    max-width: 1300px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;
}
.row{
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

.col-2{
    flex-basis: 50%;
    min-width: 300px;
}
.col-2 img{
    max-width: 100%;
    padding: 50px 0;
} 

.col-2 h1{
    font-size: 50px;
    line-height: 60px;
    margin: 25px 0;
}

.btn{
    display: inline-block;
    background: #ff523b;
    color: #fff;
    padding:8px 30px;
    margin: 30px 0px;
    border-radius: 30px;
    transition:background 0.5s;
}
.btn:hover{
    background: #563434;
}
.header{
    background: radial-gradient(#fff, #ffd6d6);
}
.header .row{
    margin-top: 70px;
}

.categories{
    margin: 70px 0;
}
.col-3{
    flex-basis: 30%;
    min-width: 250px;
    margin-bottom: 30px;
}

.col-3 img{
   width: 100%;
}

.small-container{
    max-width: 1080px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;   
}
.col-4{
    flex-basis: 25%;
    padding: 10px;
    min-width: 200px;
    margin-bottom: 50px;
    transition: transform 0.5s;
}
.col-4 img{
    width:100%;
}
    </style>
     <script>
        // Toggle menu
        function menutoggle() {
            var menuItems = document.getElementById("MenuItems");
            menuItems.style.maxHeight = menuItems.style.maxHeight === "200px" ? "0px" : "200px";
        }

        // Sort products
        function sortProducts() {
            const grid = document.getElementById('productGrid');
            const products = Array.from(grid.children);
            const sortOption = document.getElementById('sortOptions').value;

            const sortedProducts = products.sort((a, b) => {
                const aValue = parseFloat(a.dataset[sortOption] || 0);
                const bValue = parseFloat(b.dataset[sortOption] || 0);
                return sortOption === 'price' || sortOption === 'sale' ? aValue - bValue : bValue - aValue;
            });

            grid.innerHTML = '';
            sortedProducts.forEach(product => grid.appendChild(product));
        }
    </script>

</html> 
