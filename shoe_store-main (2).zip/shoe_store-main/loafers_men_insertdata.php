<?php
header('Content-Type: application/json');

// Database connection
require 'dat6abase-ecommerce/ecommerce_sql.php';

// Get POST data
$product_image = $_POST['product_image'] ?? '';
$product_base_price = $_POST['product_base_price'] ?? '';
$product_size = $_POST['product_size'] ?? '';
$product_quantity = $_POST['product_quantity'] ?? '';

// Validate input data
if (!$product_image || !$product_base_price || !$product_size || !$product_quantity) {
    echo json_encode(['success' => false, 'message' => 'Invalid input data']);
    exit;
}

$product_quantity = (int)$product_quantity; // Ensure it's an integer

try {
    // Start transaction
    $conn->begin_transaction();

    // Insert into `cart`
    $stmt1 = $conn->prepare("INSERT INTO cart (product_image, product_price, product_size, product_quantity) 
                             VALUES (?, ?, ?, ?)");
    $stmt1->bind_param("sssi", $product_image, $product_base_price, $product_size, $product_quantity);

    if (!$stmt1->execute()) {
        throw new Exception("Failed to add product to 'cart': " . $stmt1->error);
    }

    // Insert into `product_loafers_men_gray`
    $stmt2 = $conn->prepare("INSERT INTO product_loafers_men_gray (product_image, product_price, product_size, product_quantity) 
                             VALUES (?, ?, ?, ?)");
    $stmt2->bind_param("sssi", $product_image, $product_base_price, $product_size, $product_quantity);

    if (!$stmt2->execute()) {
        throw new Exception("Failed to add product to 'product_loafers_men_gray': " . $stmt2->error);
    }

    // Commit transaction
    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Product added to both tables successfully']);
} catch (Exception $e) {
    // Roll back the transaction on error
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    // Close statements and connection
    if (isset($stmt1)) $stmt1->close();
    if (isset($stmt2)) $stmt2->close();
    $conn->close();
}
?>
