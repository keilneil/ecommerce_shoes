<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Page - Redstore</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="index.html"><img src="images/logo.png" width="125px" alt="Redstore Logo"></a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="add_to_cart_show_data.php">Products</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="account_for_add_to_cart.php">Account</a></li>
                </ul>
            </nav>
            <a href="add_to_cart_show_data.php"><img src="images/cart.png" width="30px" height="30px" alt="Cart"></a>
            <img src="images/menu.png" class="menu-icon" onclick="menutoggle()" alt="Menu">
        </div>
    </div>

    <div class="account-page">
        <div class="container">
            <div class="row">
                <div class="col-2">
                    <img src="images/image1.png" width="100%" alt="Account Page Image">
                </div>
                <div class="col-2">
                    <div class="form-container">
                        <div class="form-btn">
                            <span onclick="login()">Login</span>
                            <span onclick="register()">Register</span>
                            <hr id="Indicator">
                        </div>
                        <!-- Login Form -->
                        <form action="account.php" id="LoginForm" method="post">
                            <input type="text" placeholder="Username" name="Username-login" required>
                            <input type="password" placeholder="Password" name="Password-login" required>
                            <button type="submit" class="btn" name="btn-login">Login</button>
                            <div style="color: red; margin-top: 10px;">
                                <?php if (isset($loginError)) echo $loginError; ?>
                            </div>
                        </form>
                        <!-- Register Form -->
                        <form id="RegForm" method="post">
                            <input type="text" placeholder="Username" name="username-register" required>
                            <input type="email" placeholder="Email" name="email-register" required>
                            <input type="password" placeholder="Password" name="password-register" required>
                            <button type="submit" class="btn" name="register-btn">Register</button>
                            <div style="margin-top: 10px;">
                                <button type="button" class="btn" onclick="login()">Already have an account? Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    session_start();
    include 'dat6abase-ecommerce/ecommerce_sql.php';
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Handle Registration
        if (isset($_POST['register-btn'])) {
            $username = htmlspecialchars($_POST['username-register']);
            $email = htmlspecialchars($_POST['email-register']);
            $password = htmlspecialchars($_POST['password-register']); // Removed password hashing
    
            $stmt = $conn->prepare("INSERT INTO customer_account (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $password);
    
            if ($stmt->execute()) {
                echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Account Created',
                        text: 'Your account has been created successfully!',
                    }).then(() => window.location.href = 'account_for_add_to_cart.php');
                </script>";
            } else {
                // Check for duplicate entry
                if ($stmt->errno === 1062) { // Duplicate entry error code in MySQL
                    echo "<script>
                        Swal.fire({
                            icon: 'error',
                            title: 'Registration Failed',
                            text: 'Username or Email already exists. Please try with different credentials.',
                        });
                    </script>";
                } else {
                    echo "<script>
                        Swal.fire('Error', 'Registration failed. Try again.', 'error');
                    </script>";
                }
            }
        }
    
        // Handle Login
        if (isset($_POST['btn-login'])) {
            $username = $_POST['Username-login'];
            $password = $_POST['Password-login'];
    
            $stmt = $conn->prepare("SELECT * FROM customer_account WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
    
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                if ($password === $user['password']) { // Compare plain-text passwords
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    echo "<script>window.location.href = 'add_to_cart_show_data.php';</script>";
                } else {
                    $loginError = "Invalid password.";
                }
            } else {
                $loginError = "Invalid username.";
            }
        }
    }
    
    ?>

    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and iOS mobile phones.</p>
                    <div class="app-logo">
                        <img src="images/play-store.png" alt="Play Store">
                        <img src="images/app-store.png" alt="App Store">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="images/logo-white.png" alt="Redstore Logo">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li>Coupons</li>
                        <li>Blog Post</li>
                        <li>Return Policy</li>
                        <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow Us</h3>
                    <ul>
                        <li>Facebook</li>
                        <li>Twitter</li>
                        <li>Instagram</li>
                        <li>YouTube</li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="copyright">Copyright 2021 - Redstore</p>
        </div>
    </div>

    <div id="popupForm" class="popup">
    <div class="popup-content">
        <span class="close" onclick="closePopup()">&times;</span>
        <h2>Place Your Order</h2>
        <form id="orderForm" enctype="multipart/form-data">
            <input type="text" name="customerName" placeholder="Enter Your Name" required>
            <input type="file" name="orderImage" accept="image/*" required>
            <button type="button" class="btn" onclick="submitOrder()">Submit</button>
        </form>
    </div>
</div>



    <script>
        const MenuItems = document.getElementById("MenuItems");
        MenuItems.style.maxHeight = "0px";

        function menutoggle() {
            MenuItems.style.maxHeight = MenuItems.style.maxHeight === "0px" ? "200px" : "0px";
        }

        const LoginForm = document.getElementById("LoginForm");
        const RegForm = document.getElementById("RegForm");
        const Indicator = document.getElementById("Indicator");

        function register() {
            RegForm.style.transform = "translateX(0px)";
            LoginForm.style.transform = "translateX(300px)";
            Indicator.style.transform = "translateX(100px)";
        }

        function login() {
            RegForm.style.transform = "translateX(300px)";
            LoginForm.style.transform = "translateX(0px)";
            Indicator.style.transform = "translateX(0px)";
        }
       function openCartWindow(event) {
    // Prevent the form's default submission
    event.preventDefault();

    // Reference the login form by its correct ID
    const form = document.getElementById('LoginForm');
    
    if (!form) {
        console.error("Login form not found.");
        return;
    }

    // Open a new window for the customer orders page
    const newWindow = window.open('process_order.php', '_blank', 'width=800,height=600');
    
    if (newWindow) {
        // Focus the new window
        newWindow.focus();

        // Submit the form after opening the new window
        form.submit();
    } else {
        // Alert the user if pop-ups are blocked
        alert("Please allow pop-ups for this site to proceed.");
    }

       }
       function openPopup() {
    document.getElementById("popupForm").style.display = "flex";
}

function closePopup() {
    document.getElementById("popupForm").style.display = "none";
}

function submitOrder() {
    const form = document.getElementById("orderForm");
    const formData = new FormData(form);

    fetch("process_order.php", {
        method: "POST",
        body: formData,
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                alert("Order placed successfully!");
                closePopup();
            } else {
                alert("Error: " + data.message);
            }
        })
        .catch((error) => console.error("Error:", error));
}
    </script>

    <style>
        .popup {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    justify-content: center;
    align-items: center;
}

.popup-content {
    background: white;
    padding: 20px;
    border-radius: 5px;
    text-align: center;
    width: 300px;
}

.close {
    float: right;
    font-size: 20px;
    cursor: pointer;
    color: red;
}
    </style>
</body>