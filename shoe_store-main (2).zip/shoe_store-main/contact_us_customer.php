<?php
// Include database configuration
include 'dat6abase-ecommerce/ecommerce_sql.php';

	
try {
    // Database connection
    $pdo = new PDO("mysql:host=$connsn;dbname=$conndbn", $connun, $connpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    echo "Something went wrong. Please try again later.";
    exit();
}

// Process the form data
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize and validate inputs
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $subject = htmlspecialchars(trim($_POST['subject']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Check for required fields
    if (empty($name) || empty($email) || empty($message)) {
        echo "All fields except 'Subject' are required.";
        exit();
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit();
    }

    try {
        // Insert data into the database
        $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (:name, :email, :subject, :message)");
        $stmt->execute([
            ':name' => $name,
            ':email' => $email,
            ':subject' => $subject,
            ':message' => $message,
        ]);
        echo "Your message has been sent successfully!";
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        echo "Something went wrong. Please try again later.";
    }
} else {
    echo "Invalid request method.";
}
?>
