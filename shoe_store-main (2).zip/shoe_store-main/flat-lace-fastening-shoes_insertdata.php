<?php
header('Content-Type: application/json');

// Database connection
require 'dat6abase-ecommerce/ecommerce_sql.php';

// Get POST data
$product_image = $_POST['product_image'] ?? '';
$product_base_price = $_POST['product_base_price'] ?? '';
$product_size = $_POST['product_size'] ?? '';
$product_quantity = $_POST['product_quantity'] ?? '';

// Validate input data
if (!$product_image || !$product_base_price || !$product_size || !$product_quantity) {
    echo json_encode(['success' => false, 'message' => 'Invalid input data']);
    exit;
}

// Sanitize and prepare inputs
$product_quantity = (int)$product_quantity; // Ensure quantity is an integer

try {
    // Begin a transaction
    $conn->begin_transaction();

    // Insert into 'cart' table
    $stmt1 = $conn->prepare("INSERT INTO cart (product_image, product_price, product_size, product_quantity) 
                             VALUES (?, ?, ?, ?)");
    $stmt1->bind_param("sssi", $product_image, $product_base_price, $product_size, $product_quantity);
    $stmt1->execute();

    // Insert into 'product_flat_lace_fastening_shoes' table
    $stmt2 = $conn->prepare("INSERT INTO product_flat_lace_fastening_shoes (product_image, product_price, product_size, product_quantity) 
                             VALUES (?, ?, ?, ?)");
    $stmt2->bind_param("sssi", $product_image, $product_base_price, $product_size, $product_quantity);
    $stmt2->execute();

    // Commit transaction
    $conn->commit();

    echo json_encode(['success' => true, 'message' => 'Product added to both tables successfully']);
} catch (Exception $e) {
    // Roll back transaction if something goes wrong
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
} finally {
    // Close statements and connection
    $stmt1->close();
    $stmt2->close();
    $conn->close();
}
?>
