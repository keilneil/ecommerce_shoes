<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
       
    </style>
</head>
<body>
    
    
        <section>
        <div class ="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="index.php"><img src="images/logo.png" width="125px"></a>
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="index.php">Home</a></li>
                         <li><a href="account.php">Products</a></li>
                         <li><a href="about_us.php">About</a></li>
                         <li><a href="contact_us.php">Contact</a></li>
                         <li><a href="account.php">Account</a></li>

                    </ul>
                </nav>
                <a href="add_to_cart_show_data.php"><img src="images/cart.png" width="30px" height="30px"></a>
                
            </div>
            
        </div>
    </div>
            <h2>Get in Touch</h2>
            <p>If you have any questions, comments, or concerns, feel free to contact us using the form below or through the provided contact details.</p>
          
            <form id="contactForm">
    <label for="name">Your Name</label>
    <input type="text" id="name" name="name" required placeholder="Enter your name">

    <label for="email">Your Email</label>
    <input type="email" id="email" name="email" required placeholder="Enter your email">

    <label for="subject">Subject</label>
    <input type="text" id="subject" name="subject" placeholder="Enter subject">

    <label for="message">Message</label>
    <textarea id="message" name="message" rows="5" required placeholder="Write your message"></textarea>

    <button type="submit">Send Message</button>
</form>
<div id="responseMessage"></div>
        </section>
        <section class="contact-details">
            <h2>Contact Details</h2>
            <p><strong>Email:</strong> support@yourbusiness.com</p>
            <p><strong>Phone:</strong> +1 (123) 456-7890</p>
            <p><strong>Address:</strong> 123 Business Road, City, Country</p>
        </section>
        <div class ="footer">
        <div class="container">
            
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and ios mobile phone.</p>
                    <div class="app-logo">
                        <img src="images/play-store.png" alt="">
                        <img src="images/app-store.png" alt="">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="images/logo-white.png">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                   <ul>
                       <li>Coupons</li>
                       <li>Blog Post</li>
                       <li>Return Policy</li>
                       <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow us</h3>
                   <ul>
                       <li>Facebook</li>
                       <li>Twitter</li>
                       <li>Instagram</li>
                       <li>Youtube</li>
                    </ul>
                </div>
                
            </div>
            
            <hr><!--horizontal line-->
            <p class="copyright">Copyright 2021 - Apurba Kr. Pramanik</p>
            
        </div>
    </div>
   
    <style>
        
        .footer{
    background:#000; /*black;*/
    color: #8a8a8a;
    font-size: 14px;
    padding:60px 0 20px;
}

.footer p{
    color: #8a8a8a;
}

.footer h3{
    color:#fff;
    margin-bottom: 20px;
}
.footer-col-1, .footer-col-2,.footer-col-3,.footer-col-4{
    min-width: 250px;
    margin-bottom: 20px;
}
.footer-col-1{
    flex-basis: 30%;
}
.footer-col-2{
    flex: 1;
    text-align: center;
}
.footer-col-2 img{
    width: 180px;
    margin-bottom: 20px;
}
.footer-col-3,.footer-col-4{
    flex-basis: 12%;
    text-align: center;
}
ul{
    list-style-type: none;   
}
.app-logo{
    margin-top: 20px;
}
.app-logo img{
    width: 140px;
}

.footer hr{
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}
.copyright{
    text-align: center;
}



.menu-icon{
    width: 28px;
    margin-left: 20px;  
    display:none;
}
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    font-family: 'Poppins', sans-serif;
}
/*nav maenu on the left as a unordered list*/
.navbar{
    display:flex;
    align-items: center;
    padding:20px;
}
/*nav maenu on the right as a unordered list*/
nav{
    flex: 1;
    text-align: right;
}
/*nav maenu on the right as a list but without bullet*/
nav ul{
    display: inline-block;
    list-style-type: none;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each with underline*/
nav ul li{
    display: inline-block;
    margin-right: 50px;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each without underline*/
a{
    text-decoration: none;
    color: #555;
}
p{
    color: #555;
}
.container{
    max-width: 1300px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;
}
.row{
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

.col-2{
    flex-basis: 50%;
    min-width: 300px;
}
.col-2 img{
    max-width: 100%;
    padding: 50px 0;
} 

.col-2 h1{
    font-size: 50px;
    line-height: 60px;
    margin: 25px 0;
}

.btn{
    display: inline-block;
    background: #ff523b;
    color: #fff;
    padding:8px 30px;
    margin: 30px 0px;
    border-radius: 30px;
    transition:background 0.5s;
}
.btn:hover{
    background: #563434;
}
.header{
    background: radial-gradient(#fff, #ffd6d6);
}
.header .row{
    margin-top: 70px;
}

.categories{
    margin: 70px 0;
}
.col-3{
    flex-basis: 30%;
    min-width: 250px;
    margin-bottom: 30px;
}

.col-3 img{
   width: 100%;
}

.small-container{
    max-width: 1080px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;   
}
.col-4{
    flex-basis: 25%;
    padding: 10px;
    min-width: 200px;
    margin-bottom: 50px;
    transition: transform 0.5s;
}
.col-4 img{
    width:100%;
}
.title{
    text-align: center;
    margin: 0 auto 80px;
    position: relative;
    line-height: 60px;
    color: #555;
}
.title::after{
    content: '';
    background: #ff523b;
    width: 80px;
    height: 5px;
    border-radius: 5px;
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
}
h4{
    color: #555;
    font-weight: normal;
}
.col-4 p{
    font-size: 14px;
}
.rating .fa{
    color: #ff523b;
}
.col-4:hover{
    transform:translateY(-5px);
}
/*for username confirmation*/

 

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f9f9f9;
    color: #5a3d2b; /* Brown text color */
}
h2 {
    color: #8b4513; /* SaddleBrown */
    margin-bottom: 10px;
    text-align: center;
}
p {
    line-height: 1.6;
    margin-bottom: 15px;
    text-align: center;
}

/* Form Section */
form {
    display: flex;
    flex-direction: column;
    max-width: 600px;
    margin: 0 auto 30px auto;
    padding: 20px;
    background: #fff;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}
form label {
    font-weight: bold;
    margin-bottom: 5px;
    color: #5a3d2b; /* Brown label text color */
}
form input, form textarea, form button {
    margin-bottom: 15px;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #8b4513; /* SaddleBrown border */
    border-radius: 5px;
    width: 100%;
}
form textarea {
    resize: vertical;
}
form button {
    background-color: #8b4513; /* SaddleBrown */
    color: white;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s;
}
form button:hover {
    background-color: #5a3d2b; /* Darker brown */
}

/* Contact Details Section */
.contact-details {
    margin: 30px auto;
    padding: 20px;
    max-width: 600px;
    background: #fff;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    border-left: 5px solid #8b4513; /* Add a decorative border */
    border-radius: 8px;
}
.contact-details h2 {
    text-align: center;
    color: #8b4513; /* SaddleBrown */
    margin-bottom: 15px;
}
.contact-details p {
    margin: 10px 0;
    font-size: 16px;
    text-align: left;
    color: #5a3d2b; /* Brown text color */
    padding: 5px 10px;
    border-bottom: 1px dashed #ccc; /* Add subtle separation */
}
.contact-details p:last-child {
    border-bottom: none; /* Remove the border for the last item */
}
.contact-details p strong {
    color: #8b4513; /* SaddleBrown */
}

/* Responsive Design */
@media (max-width: 768px) {
    form, .contact-details {
        padding: 15px;
    }
    form input, form textarea, form button {
        font-size: 14px;
        padding: 8px;
    }
    .contact-details p {
        font-size: 14px;
    }
}

@media (max-width: 480px) {
    form, .contact-details {
        padding: 10px;
    }
    form input, form textarea, form button {
        font-size: 12px;
        padding: 6px;
    }
    .contact-details p {
        font-size: 12px;
    }
}

    </style>
    <script>
        document.getElementById('contactForm').addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent the default form submission

        // Collect form data
        const formData = new FormData(this);

        // Send data to PHP using Fetch API
        fetch('contact_us_customer.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text()) // Handle the PHP response as text
        .then(data => {
            // Display the response message
            document.getElementById('responseMessage').innerText = data;
        })
        .catch(error => {
            // Handle errors
            console.error('Error:', error);
            document.getElementById('responseMessage').innerText = 'An error occurred. Please try again.';
        });
    });
    </script>
</body>
</html>
