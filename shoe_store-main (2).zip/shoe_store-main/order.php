<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
<div class ="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="index.php"><img src="images/logo.png" width="125px"></a>
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="index.php">Home</a></li>
                         <li><a href="products.php">Products</a></li>
                         <li><a href="">About</a></li>
                         <li><a href="">Contact</a></li>
                         <li><a href="account.php">Account</a></li>

                    </ul>
                </nav>
                <a href="add_to_cart_show_data.php"><img src="images/cart.png" width="30px" height="30px"></a>
                
            </div>
            
        </div>
    </div>
        
    <div class="cart-container">
    <?php
    // Database connection
    $conn = new mysqli('localhost', 'root', 'kiel12345678910', 'ecommerce_shoes');
    if ($conn->connect_error) {
        die('Database connection failed: ' . $conn->connect_error);
    }

    // Query to fetch orders
    $sql = "SELECT * FROM orders";
    $result = $conn->query($sql);

    if ($result->num_rows > 0): // Check if there are orders
    ?>
        <table border="1" cellspacing="0" cellpadding="10">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Size</th>
                    <th>Product Quantity</th>
                    <th>Total Price</th>
                    <th>Username</th>
                    <th>Address</th>
                    <th>Cellphone</th>
                    <th>Payment Method</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['product_size']); ?></td>
                    <td><?php echo htmlspecialchars($row['product_quantity']); ?></td>
                    <td><?php echo htmlspecialchars($row['total_price']); ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['address']); ?></td>
                    <td><?php echo htmlspecialchars($row['cellphone']); ?></td>
                    <td><?php echo htmlspecialchars($row['payment_method']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php
    else:
    ?>
        <p>No orders found.</p>
    <?php
    endif;

    $conn->close();
    ?>
</div>


    <!-- Edit Modal -->
    

    <!-- Edit Modal -->
    
    
   
      
    
   <!-- Username Modal -->


<!-- Confirmation Modal -->






<div class ="footer">
        <div class="container">
            
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and ios mobile phone.</p>
                    <div class="app-logo">
                        <img src="images/play-store.png" alt="">
                        <img src="images/app-store.png" alt="">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="images/logo-white.png">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                   <ul>
                       <li>Coupons</li>
                       <li>Blog Post</li>
                       <li>Return Policy</li>
                       <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow us</h3>
                   <ul>
                       <li>Facebook</li>
                       <li>Twitter</li>
                       <li>Instagram</li>
                       <li>Youtube</li>
                    </ul>
                </div>
                
            </div>
            
            <hr><!--horizontal line-->
            <p class="copyright">Copyright 2021 - Apurba Kr. Pramanik</p>
            
        </div>
    </div>
    <style>
       
/* General Reset */




.footer{
    background:#000; /*black;*/
    color: #8a8a8a;
    font-size: 14px;
    padding:60px 0 20px;
}

.footer p{
    color: #8a8a8a;
}

.footer h3{
    color:#fff;
    margin-bottom: 20px;
}
.footer-col-1, .footer-col-2,.footer-col-3,.footer-col-4{
    min-width: 250px;
    margin-bottom: 20px;
}
.footer-col-1{
    flex-basis: 30%;
}
.footer-col-2{
    flex: 1;
    text-align: center;
}
.footer-col-2 img{
    width: 180px;
    margin-bottom: 20px;
}
.footer-col-3,.footer-col-4{
    flex-basis: 12%;
    text-align: center;
}
ul{
    list-style-type: none;   
}
.app-logo{
    margin-top: 20px;
}
.app-logo img{
    width: 140px;
}

.footer hr{
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}
.copyright{
    text-align: center;
}



.menu-icon{
    width: 28px;
    margin-left: 20px;  
    display:none;
}
 
    </style>

    <script>


// Function to handle editing cart item


</script>


<style>
      *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    font-family: 'Poppins', sans-serif;
}
/*nav maenu on the left as a unordered list*/
.navbar{
    display:flex;
    align-items: center;
    padding:20px;
}
/*nav maenu on the right as a unordered list*/
nav{
    flex: 1;
    text-align: right;
}
/*nav maenu on the right as a list but without bullet*/
nav ul{
    display: inline-block;
    list-style-type: none;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each with underline*/
nav ul li{
    display: inline-block;
    margin-right: 50px;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each without underline*/
a{
    text-decoration: none;
    color: #555;
}
p{
    color: #555;
}
.container{
    max-width: 1300px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;
}
.row{
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

.col-2{
    flex-basis: 50%;
    min-width: 300px;
}
.col-2 img{
    max-width: 100%;
    padding: 50px 0;
} 

.col-2 h1{
    font-size: 50px;
    line-height: 60px;
    margin: 25px 0;
}

.btn{
    display: inline-block;
    background: #ff523b;
    color: #fff;
    padding:8px 30px;
    margin: 30px 0px;
    border-radius: 30px;
    transition:background 0.5s;
}
.btn:hover{
    background: #563434;
}
.header{
    background: radial-gradient(#fff, #ffd6d6);
}
.header .row{
    margin-top: 70px;
}

.categories{
    margin: 70px 0;
}
.col-3{
    flex-basis: 30%;
    min-width: 250px;
    margin-bottom: 30px;
}

.col-3 img{
   width: 100%;
}

.small-container{
    max-width: 1080px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;   
}
.col-4{
    flex-basis: 25%;
    padding: 10px;
    min-width: 200px;
    margin-bottom: 50px;
    transition: transform 0.5s;
}
.col-4 img{
    width:100%;
}
.title{
    text-align: center;
    margin: 0 auto 80px;
    position: relative;
    line-height: 60px;
    color: #555;
}
.title::after{
    content: '';
    background: #ff523b;
    width: 80px;
    height: 5px;
    border-radius: 5px;
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
}
h4{
    color: #555;
    font-weight: normal;
}
.col-4 p{
    font-size: 14px;
}
.rating .fa{
    color: #ff523b;
}
.col-4:hover{
    transform:translateY(-5px);
}
body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        background-color: #f4f4f9;
        color: #333;
    }

    .cart-container {
        max-width: 1200px;
        margin: 20px auto;
        padding: 15px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        overflow-x: auto; /* Enables horizontal scroll on smaller devices */
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    table th,
    table td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
    }

    table th {
        background-color: #007BFF;
        color: #fff;
    }

    table tbody tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    table tbody tr:hover {
        background-color: #f1f1f1;
    }

    @media screen and (max-width: 768px) {
        table th,
        table td {
            padding: 8px;
            font-size: 14px;
        }
    }

    @media screen and (max-width: 480px) {
        table th,
        table td {
            font-size: 12px;
            padding: 6px;
        }

        .cart-container {
            padding: 10px;
        }

        table {
            font-size: 12px;
        }
    }

    p {
        text-align: center;
        font-size: 16px;
        color: #888;
    }
    .cart-container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 15px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow-x: auto; /* Enables horizontal scroll for small screens */
}

.table-wrapper {
    max-height: 400px; /* Set max height for the table container */
    overflow-y: auto; /* Enable vertical scrolling if data overflows */
    border: 1px solid #ddd;
    border-radius: 8px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

table th,
table td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
}

table th {
    background-color: #007BFF;
    color: #fff;
}

table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

table tbody tr:hover {
    background-color: #f1f1f1;
}

@media screen and (max-width: 768px) {
    table th,
    table td {
        padding: 8px;
        font-size: 14px;
    }
}

@media screen and (max-width: 480px) {
    table th,
    table td {
        font-size: 12px;
        padding: 6px;
    }

    .cart-container {
        padding: 10px;
    }

    table {
        font-size: 12px;
    }
}

p {
    text-align: center;
    font-size: 16px;
    color: #888;
}

</style>

</html>


