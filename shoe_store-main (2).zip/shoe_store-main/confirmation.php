<?php
// confirmation.php
header('Content-Type: application/json');
require_once 'dat6abase-ecommerce/ecommerce_sql.php'; // Include the database connection

if (isset($_POST['username'])) {
    $username = $_POST['username'];
    $stmt = $conn->prepare("SELECT * FROM customer_account WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Username verified']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Username not found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Username not provided']);
}
?>
