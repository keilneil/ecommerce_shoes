<?php
// Include database configuration
include 'dat6abase-ecommerce/ecommerce_sql.php';

try {
    // Establish a database connection
    $conn = new PDO("mysql:host=$connsn;dbname=$conndbn", $connun, $connpass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Unable to connect to the database.']);
    exit();
}

// Get POST data and validate
$productId = isset($_POST['productId']) ? trim($_POST['productId']) : null;
$productSize = isset($_POST['productSize']) ? trim($_POST['productSize']) : null;
$productQuantity = isset($_POST['productQuantity']) ? trim($_POST['productQuantity']) : null;
$totalPrice = isset($_POST['totalPrice']) ? trim($_POST['totalPrice']) : null;
$username = isset($_POST['username']) ? trim($_POST['username']) : null;
$address = isset($_POST['address']) ? trim($_POST['address']) : null;
$cellphone = isset($_POST['cellphone']) ? trim($_POST['cellphone']) : null;
$paymentMethod = isset($_POST['paymentMethod']) ? trim($_POST['paymentMethod']) : null;

// Validate required fields
if (!$productId || !$productSize || !$productQuantity || !$totalPrice || 
    !$username || !$address || !$cellphone || !$paymentMethod) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit();
}

// Insert order into the database
try {
    $query = "INSERT INTO orders (product_id, product_size, product_quantity, total_price, username, address, cellphone, payment_method) 
              VALUES (:productId, :productSize, :productQuantity, :totalPrice, :username, :address, :cellphone, :paymentMethod)";
    $stmt = $conn->prepare($query);
    $stmt->execute([
        ':productId' => htmlspecialchars($productId),
        ':productSize' => htmlspecialchars($productSize),
        ':productQuantity' => htmlspecialchars($productQuantity),
        ':totalPrice' => htmlspecialchars($totalPrice),
        ':username' => htmlspecialchars($username),
        ':address' => htmlspecialchars($address),
        ':cellphone' => htmlspecialchars($cellphone),
        ':paymentMethod' => htmlspecialchars($paymentMethod),
    ]);

    echo json_encode(['success' => true, 'message' => 'Order placed successfully.']);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to place order.']);
}
?>
