<?php
// Database configuration
include 'dat6abase-ecommerce/ecommerce_sql.php';
// Check the connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]));
}

// Handle the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : null;
    $size = isset($_POST['size']) ? $conn->real_escape_string($_POST['size']) : null;

    if (!$id || !$quantity || !$size) {
        echo json_encode(['success' => false, 'message' => 'Invalid input']);
        exit;
    }

    // Update the product in the database
    $sql = "UPDATE flat_lace_fastening_shoes SET product_quantity = ?, product_size = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('isi', $quantity, $size, $id);

    if ($stmt->execute()) {
        // Product updated successfully, fetch the updated product details
        // Assuming you want to return the updated product data in the response
        $productDetails = [
            'id' => $id,
            'quantity' => $quantity,
            'size' => $size,
            'price' => 49.00 // Use the fetched price from the database or keep a static value
        ];

        echo json_encode([
            'success' => true,
            'message' => 'Product updated successfully',
            'data' => $productDetails
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update product']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
