<?php
// Database configuration
include 'dat6abase-ecommerce/ecommerce_sql.php';
// Check the connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]));
}

// Handle the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;

    // Check if the product ID is valid
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
        exit;
    }

    // Fetch product data from the database
    $sql = "SELECT product_quantity, product_size, product_price FROM flat_lace_fastening_shoes WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch product details
        $product = $result->fetch_assoc();
        $productDetails = [
            'id' => $id,
            'quantity' => $product['product_quantity'],
            'size' => $product['product_size'],
            'price' => $product['product_price'] // Assuming the price is stored in the database
        ];

        // Send response back as JSON
        echo json_encode([
            'success' => true,
            'message' => 'Product data received successfully',
            'data' => $productDetails
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
