<style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
}

.cart-container {
    width: 80%;
    margin: 20px auto;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.cart-item {
    display: flex;
    background-color: white;
    padding: 20px;
    margin: 10px 0;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 800px;
    justify-content: space-between;
}

.product-image {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border-radius: 8px;
}

.cart-item-info {
    flex-grow: 1;
    margin-left: 20px;
}

.cart-item-actions {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    text-align: center;
}

button {
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-bottom: 10px;
}

.edit-btn {
    background-color: #4CAF50;
    color: white;
}

button:hover {
    opacity: 0.8;
}

.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
}

.modal-content {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    width: 300px;
}

.close {
    position: absolute;
    top: 10px;
    right: 10px;
    cursor: pointer;
}

   </style>