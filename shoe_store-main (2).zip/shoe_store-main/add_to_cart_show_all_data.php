<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
<div class ="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="index.html"><img src="images/logo.png" width="125px"></a>
                </div>
                <nav>
                    <ul id="MenuItems">
                        <li><a href="index.html">Home</a></li>
                         <li><a href="products.php">Products</a></li>
                         <li><a href="">About</a></li>
                         <li><a href="">Contact</a></li>
                         <li><a href="account.php">Account</a></li>

                    </ul>
                </nav>
                <a href="add_to_cart_show_all_data.php"><img src="images/cart.png" width="30px" height="30px"></a>
                
            </div>
            
        </div>
    </div>
        
    <div class="cart-container">
        <?php
        $conn = new mysqli('localhost', 'root', 'kiel12345678910', 'ecommerce_shoes');
        if ($conn->connect_error) {
            die('Database connection failed: ' . $conn->connect_error);
        }

        $sql = "SELECT * FROM cart";
        $result = $conn->query($sql);

        if ($result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
        <div class="cart-item">
            <img src="<?= htmlspecialchars($row['product_image']) ?>" alt="Product Image" class="product-image">
            <div class="cart-item-info">
                <p><strong>Product ID:</strong> <?= htmlspecialchars($row['id']) ?></p>
                <p><strong>Price:</strong> $<?= htmlspecialchars($row['product_price']) ?></p>
                <p><strong>Size:</strong> <?= htmlspecialchars($row['product_size']) ?></p>
                <p><strong>Quantity:</strong> <?= htmlspecialchars($row['product_quantity']) ?></p>
            </div>
            <div class="cart-item-actions">
               
            <button class="edit-btn" onclick="editCartItem(<?= $row['id'] ?>, <?= $row['product_quantity'] ?>, '<?= $row['product_size'] ?>')">Edit</button>
                <button class="buy-btn" onclick="showUsernameModal(<?= $row['id'] ?>)">Buy Now</button>
            </div>
        </div>
        
        
        <?php
            endwhile;
        else:
        ?>
        <p>No items in the cart.</p>
        <?php
        endif;

        $conn->close();
        ?>
    </div>

    <!-- Edit Modal -->
    

    <!-- Edit Modal -->

    <!-- Edit Button -->
<button class="edit-btn" onclick="openUserVerificationModal(<?= $row['id'] ?>, <?= $row['product_quantity'] ?>, '<?= $row['product_size'] ?>')">Edit</button>

<!-- Username Verification Modal -->
<div id="editModal" style="display: none">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>Edit Product</h2>
        <form id="editForm">
            <div class="form-group">
                <label for="editId">ID</label>
                <input type="text" id="editId" name="id" readonly>
            </div>
            <div class="form-group">
                <label for="editQuantity">Quantity</label>
                <input type="number" id="editQuantity" name="quantity" required>
            </div>
            <div class="form-group">
                <label for="editSize">Size</label>
                <select id="editSize" name="size" required>
                    <option value="">Select a size</option>
                    <option value="small">Small</option>
                    <option value="medium">Medium</option>
                    <option value="large">Large</option>
                 
                </select>
            </div>
            <button type="submit" class="btn">Save Changes</button>
        </form>
    </div>
</div>
    <div id="usernameModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeUsernameModal()">&times;</span>
        <h3>Enter Username</h3>
        <input type="text" id="usernameInput" placeholder="Enter your username" />
        <button onclick="verifyUsername()">Submit</button>
    </div>
</div>

<!-- Confirmation Modal -->
<div id="confirmationModal" class="modal">
    <div class="modal-content">
        <h3>Order Confirmation</h3>
        <p id="product-size"></p>
        <p id="product-quantity"></p>
        <p id="total-price"></p>
        <input type="text" id="username" placeholder="Username" disabled />
        <input type="text" id="address" placeholder="Enter address" />
        <input type="text" id="cellphone" placeholder="Enter cellphone" />
        <select id="payment-method">
            <option value="">Select Payment Method</option>
            <option value="Credit Card">Credit Card</option>
            <option value="PayPal">PayPal</option>
        </select>
        <button onclick="placeOrder()">Place Order</button>
        <button onclick="closeConfirmationModal()">Cancel</button>
    </div>
</div>


<!-- Hidden Input for Product ID -->
<input type="hidden" id="order-product-id" value="1" />

<div class ="footer">
        <div class="container">
            
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and ios mobile phone.</p>
                    <div class="app-logo">
                        <img src="images/play-store.png" alt="">
                        <img src="images/app-store.png" alt="">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="images/logo-white.png">
                    <p>Our Purpose Is To Sustainably Make the Pleasure and Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                   <ul>
                       <li>Coupons</li>
                       <li>Blog Post</li>
                       <li>Return Policy</li>
                       <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow us</h3>
                   <ul>
                       <li>Facebook</li>
                       <li>Twitter</li>
                       <li>Instagram</li>
                       <li>Youtube</li>
                    </ul>
                </div>
                
            </div>
            
            <hr><!--horizontal line-->
            <p class="copyright">Copyright 2021 - Apurba Kr. Pramanik</p>
            
        </div>
    </div>
        
    <style>
       
/* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
    line-height: 1.6;
}

/* Cart Container */
.cart-container {
    width: 140%;
    max-width: 1300px;
    margin: 20px auto;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 50px;
    margin-top: 0%;
    max-height: 400px;
    overflow-y: auto;
}

.cart-item {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

.cart-item:last-child {
    border-bottom: none;
}

.product-image {
    width: 80px;
    height: 80px;
    object-fit: cover;
    margin-right: 15px;
    border-radius: 5px;
}

.cart-item-info {
    flex: 1;
}

.cart-item-info p {
    margin: 5px 0;
}

.cart-item-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.edit-btn,
.buy-btn {
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.edit-btn {
    background-color: #007bff;
    color: white;
}

.edit-btn:hover {
    background-color: #0056b3;
}

.buy-btn {
    background-color: #28a745;
    color: white;
}

.buy-btn:hover {
    background-color: #218838;
}

.no-items {
    text-align: center;
    font-size: 16px;
    color: #666;
}
/* General Modal Styling */
#editModal {
    display: none; /* Initially hidden */
    position: fixed; /* Position relative to the viewport */
    top: 0;
    left: 0;
    width: 100%;
    height: 200%;
    background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent overlay */
    z-index: 1000;
    display: flex;
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
}

/* Modal Content Styling */
#editModal .modal-content {
    background-color: #fff;
    padding: 25px;
    border-radius: 10px;
    width: 90%;
    max-width: 400px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    margin: auto; /* Center the modal content */
    text-align: center; /* Center the content inside */
    position: relative; /* For positioning the close button */
}

/* Close Button Styling */
#editModal .close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px;
    font-weight: bold;
    color: #aaa;
    cursor: pointer;
    transition: color 0.3s;
}

#editModal .close:hover {
    color: #333;
}

/* Form Group Styling */
#editModal .form-group {
    margin-bottom: 15px;
    width: 100%; /* Make inputs span the full width of the modal */
}

#editModal .form-group label {
    font-size: 14px;
    font-weight: bold;
    color: #333;
    margin-bottom: 5px;
    display: block;
}

#editModal .form-group input,
#editModal .form-group select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    box-sizing: border-box;
    transition: border-color 0.3s;
}

#editModal .form-group input:focus,
#editModal .form-group select:focus {
    border-color: #007bff; /* Highlight input on focus */
    outline: none;
}

/* Button Styling */
#editModal .btn {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    width: 100%; /* Make the button span the full width */
    margin-top: 10px;
    transition: background-color 0.3s, transform 0.2s;
}

#editModal .btn:hover {
    background-color: #0056b3;
    transform: scale(1.02); /* Slightly enlarge the button on hover */
}

#editModal .btn:active {
    transform: scale(0.98); /* Slightly shrink the button on click */
}

/* Responsive Design */
@media (max-width: 480px) {
    #editModal .modal-content {
        width: 95%; /* Reduce padding on smaller screens */
        padding: 20px;
    }

    #editModal .btn {
        font-size: 14px; /* Adjust button size for smaller screens */
    }
}



.footer{
    background:#000; /*black;*/
    color: #8a8a8a;
    font-size: 14px;
    padding:60px 0 20px;
}

.footer p{
    color: #8a8a8a;
}

.footer h3{
    color:#fff;
    margin-bottom: 20px;
}
.footer-col-1, .footer-col-2,.footer-col-3,.footer-col-4{
    min-width: 250px;
    margin-bottom: 20px;
}
.footer-col-1{
    flex-basis: 30%;
}
.footer-col-2{
    flex: 1;
    text-align: center;
}
.footer-col-2 img{
    width: 180px;
    margin-bottom: 20px;
}
.footer-col-3,.footer-col-4{
    flex-basis: 12%;
    text-align: center;
}
ul{
    list-style-type: none;   
}
.app-logo{
    margin-top: 20px;
}
.app-logo img{
    width: 140px;
}

.footer hr{
    border: none;
    background: #b5b5b5;
    height: 1px;
    margin: 20px 0;
}
.copyright{
    text-align: center;
}



.menu-icon{
    width: 28px;
    margin-left: 20px;  
    display:none;
}

    </style>

    <script>



// Store current product details globally
let currentProduct = null;

// Open Username Verification Modal
function openUserVerificationModal(id, quantity, size) {
    currentProduct = { id, quantity, size }; // Save product details
    document.getElementById('userVerificationModal').style.display = 'block';
}

// Close Username Verification Modal
function closeUserVerificationModal() {
    document.getElementById('userVerificationModal').style.display = 'none';
}

// Close Edit Modal
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Submit Username Verification
async function submitUserVerification() {
    const username = document.getElementById('userVerificationInput').value;

    try {
        const response = await fetch('confirmation.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `username=${encodeURIComponent(username)}`,
        });

        const result = await response.json();

        if (result.success) {
            // Close username modal and open edit modal
            document.getElementById('userVerificationModal').style.display = 'none';
            openEditProductModal();
        } else {
            alert('Invalid username. Please try again.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An unexpected error occurred.');
    }
}

// Open Edit Product Modal
function openEditProductModal() {
    if (currentProduct) {
        document.getElementById('editId').value = currentProduct.id;
        document.getElementById('editQuantity').value = currentProduct.quantity;
        document.getElementById('editSize').value = currentProduct.size;
        document.getElementById('editModal').style.display = 'block';
    }
}

// Handle Edit Form Submission
document.getElementById('editForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const id = document.getElementById('editId').value;
    const quantity = document.getElementById('editQuantity').value;
    const size = document.getElementById('editSize').value;

    try {
        const response = await fetch('edit_product.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `id=${encodeURIComponent(id)}&quantity=${encodeURIComponent(quantity)}&size=${encodeURIComponent(size)}`,
        });

        const result = await response.json();

        if (result.success) {
            alert('Product updated successfully!');
            closeEditModal();
            location.reload(); // Reload to reflect changes
        } else {
            alert('Failed to update product.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An unexpected error occurred.');
    }
});

       


// Show username modal with product ID
function showUsernameModal(productId) {
    document.getElementById('usernameModal').style.display = 'flex';
    document.getElementById('order-product-id').value = productId;
}

// Close username modal
function openUsernameModal() {
    document.getElementById("usernameModal").style.display = "block";
}

function closeUsernameModal() {
    document.getElementById("usernameModal").style.display = "none";
}

function openConfirmationModal(username) {
    document.getElementById("confirmationModal").style.display = "block";
    document.getElementById("username").value = username; // Display username in the confirmation modal
}

function closeConfirmationModal() {
    document.getElementById("confirmationModal").style.display = "none";
}

function verifyUsername() {
    const username = document.getElementById('usernameInput').value;

    if (!username.trim()) {
        Swal.fire('Error', 'Username is required.', 'error');
        return;
    }

    fetch('confirmation.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username)}`
    })
    .then((response) => response.json())
    .then((data) => {
        if (data.success) {
            Swal.fire('Success', data.message, 'success').then(() => {
                closeUsernameModal();
                openConfirmationModal(username); // Open confirmation modal with the username
            });
        } else {
            Swal.fire('Error', data.message, 'error');
        }
    })
    .catch((error) => {
        console.error('Error:', error);
        Swal.fire('Error', 'An error occurred while verifying the username.', 'error');
    });
}


// Fetch product details
function fetchProductDetails() {
    const productId = document.getElementById('order-product-id').value;

    console.log("Fetching product details for Product ID:", productId);

    fetch('edit.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${encodeURIComponent(productId)}`,
    })
        .then((response) => response.json())
        .then((data) => {
            console.log("Server Response:", data);

            if (data.success) {
                // Update the modal with product details
                document.getElementById('product-size').textContent = `Size: ${data.data.size}`;
                document.getElementById('product-quantity').textContent = `Quantity: ${data.data.quantity}`;
                const totalPrice = (data.data.price && data.data.quantity) 
                    ? (data.data.price * data.data.quantity).toFixed(2) 
                    : 'N/A';
                document.getElementById('total-price').textContent = `Total: $${totalPrice}`;
                document.getElementById('confirmationModal').style.display = 'block';
            } else {
                Swal.fire('Error', 'Failed to fetch product details: ' + data.message, 'error');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            Swal.fire('Error', 'An error occurred while fetching product details.', 'error');
        });
}

// Close confirmation modal
function closeConfirmationModal() {
    document.getElementById('confirmationModal').style.display = 'none';
}
function placeOrder() {
    const username = document.getElementById("username").value;
    const address = document.getElementById("address").value;
    const cellphone = document.getElementById("cellphone").value;
    const paymentMethod = document.getElementById("payment-method").value;

    // For now, just log the order details
    console.log({
        username,
        address,
        cellphone,
        paymentMethod
    });

    Swal.fire('Success', 'Your order has been placed!', 'success');
    closeConfirmationModal();
}


// Place order
function placeOrder() {
    const address = document.getElementById('address').value;
    const cellphone = document.getElementById('cellphone').value;
    const paymentMethod = document.getElementById('payment-method').value;
    const productId = document.getElementById('order-product-id').value;

    if (!address || !cellphone || !paymentMethod) {
        Swal.fire('Error', 'Please fill all the required fields.', 'error');
        return;
    }

    fetch('placeOrder.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `productId=${encodeURIComponent(productId)}&address=${encodeURIComponent(address)}&cellphone=${encodeURIComponent(cellphone)}&paymentMethod=${encodeURIComponent(paymentMethod)}`,
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                Swal.fire('Success', 'Order placed successfully!', 'success').then(() => {
                    closeConfirmationModal();
                });
            } else {
                Swal.fire('Error', 'Failed to place order: ' + data.message, 'error');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            Swal.fire('Error', 'An error occurred while placing the order.', 'error');
        });
}

    </script>
    <style>
       *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    font-family: 'Poppins', sans-serif;
}
/*nav maenu on the left as a unordered list*/
.navbar{
    display:flex;
    align-items: center;
    padding:20px;
}
/*nav maenu on the right as a unordered list*/
nav{
    flex: 1;
    text-align: right;
}
/*nav maenu on the right as a list but without bullet*/
nav ul{
    display: inline-block;
    list-style-type: none;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each with underline*/
nav ul li{
    display: inline-block;
    margin-right: 50px;   
}
/*nav maenu on the right as a vertically list with 50px gapping with each without underline*/
a{
    text-decoration: none;
    color: #555;
}
p{
    color: #555;
}
.container{
    max-width: 1300px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;
}
.row{
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: space-around;
}

.col-2{
    flex-basis: 50%;
    min-width: 300px;
}
.col-2 img{
    max-width: 100%;
    padding: 50px 0;
} 

.col-2 h1{
    font-size: 50px;
    line-height: 60px;
    margin: 25px 0;
}

.btn{
    display: inline-block;
    background: #ff523b;
    color: #fff;
    padding:8px 30px;
    margin: 30px 0px;
    border-radius: 30px;
    transition:background 0.5s;
}
.btn:hover{
    background: #563434;
}
.header{
    background: radial-gradient(#fff, #ffd6d6);
}
.header .row{
    margin-top: 70px;
}

.categories{
    margin: 70px 0;
}
.col-3{
    flex-basis: 30%;
    min-width: 250px;
    margin-bottom: 30px;
}

.col-3 img{
   width: 100%;
}

.small-container{
    max-width: 1080px;
    margin: auto;
    padding-left: 25px;
    padding-right: 25px;   
}
.col-4{
    flex-basis: 25%;
    padding: 10px;
    min-width: 200px;
    margin-bottom: 50px;
    transition: transform 0.5s;
}
.col-4 img{
    width:100%;
}
.title{
    text-align: center;
    margin: 0 auto 80px;
    position: relative;
    line-height: 60px;
    color: #555;
}
.title::after{
    content: '';
    background: #ff523b;
    width: 80px;
    height: 5px;
    border-radius: 5px;
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
}
h4{
    color: #555;
    font-weight: normal;
}
.col-4 p{
    font-size: 14px;
}
.rating .fa{
    color: #ff523b;
}
.col-4:hover{
    transform:translateY(-5px);
}
/*for username confirmation*/

/* General Modal Styling */
.modal {
    display: none; /* Initially hidden */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
    z-index: 1000;
}

/* Modal Content */
.modal-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    width: 90%;
    max-width: 400px;
    margin: auto; /* Center the modal content */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    text-align: center;
    animation: fadeInScale 0.4s ease-out; /* Animation on modal appearance */
    position: relative;
}

/* Close Button Styling */
.modal-content .close {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px;
    font-weight: bold;
    color: #aaa;
    cursor: pointer;
    transition: color 0.3s;
}

.modal-content .close:hover {
    color: #333;
}

/* Input Styling */
.modal-content input[type="text"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    margin-bottom: 15px;
    box-sizing: border-box;
    transition: border-color 0.3s;
}

.modal-content input[type="text"]:focus {
    border-color: #007bff; /* Highlight input on focus */
    outline: none;
}

/* Button Styling */
.modal-content button {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    width: 100%; /* Button spans full width */
    margin-top: 10px;
    transition: background-color 0.3s, transform 0.2s;
}

.modal-content button:hover {
    background-color: #0056b3;
    transform: scale(1.02); /* Slight hover effect */
}

.modal-content button:active {
    transform: scale(0.98); /* Slight shrink effect on click */
}

/* Animation for Modal Appearance */
@keyframes fadeInScale {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

/* Responsive Design */
@media (max-width: 480px) {
    .modal-content {
        width: 95%; /* Slightly smaller width for mobile */
        padding: 15px;
    }

    .modal-content button {
        font-size: 14px; /* Adjust button size for smaller screens */
    }
}
/*For confirmation orders*/
/* General Modal Styling */
.modal {
    display: none; /* Initially hidden */
    position: fixed; /* Stay in viewport */
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
    z-index: 1000;
}

/* Modal Content Styling */
.modal-content {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    width: 90%;
    max-width: 400px;
    margin: auto; /* Center the modal content */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    text-align: center;
    animation: fadeInScale 0.4s ease-out; /* Smooth appearance animation */
    position: relative;
}

/* Modal Header Styling */
.modal-content h3 {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 15px;
    color: #333;
}

/* Paragraph Styling */
.modal-content p {
    font-size: 16px;
    color: #555;
    margin: 10px 0;
}

/* Input Fields Styling */
.modal-content input[type="text"],
.modal-content select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    box-sizing: border-box;
    transition: border-color 0.3s;
}

.modal-content input:focus,
.modal-content select:focus {
    border-color: #007bff; /* Highlight border on focus */
    outline: none;
}

/* Buttons Styling */
.modal-content button {
    padding: 10px 15px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin: 10px 5px;
    transition: background-color 0.3s, transform 0.2s;
}

.modal-content button:first-of-type {
    background-color: #4CAF50; /* Green for "Place Order" */
    color: white;
}

.modal-content button:last-of-type {
    background-color: #f44336; /* Red for "Cancel" */
    color: white;
}

.modal-content button:hover {
    opacity: 0.9;
    transform: scale(1.02); /* Slightly enlarge on hover */
}

.modal-content button:active {
    transform: scale(0.98); /* Slight shrink on click */
}

/* Animation for Modal Appearance */
@keyframes fadeInScale {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

/* Responsive Design */
@media (max-width: 480px) {
    .modal-content {
        width: 95%;
        padding: 15px;
    }

    .modal-content button {
        font-size: 14px;
        width: 100%; /* Full-width buttons on small screens */
    }
}


    </style>
</body>

</html>


