<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details - E-commerce</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="index.html"><img src="images/logo.png" width="125px" alt="Logo"></a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="account.html">Account</a></li>
                </ul>
            </nav>
            <a href="add_to_cart_show_data.php"><img src="images/cart.png" width="30px" height="30px" alt="Cart"></a>
        </div>
    </div>

    <div class="small-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="images/product-10.jpg" width="100%" id="productImg" alt="Main Product Image">
            </div>

            <div class="col-2">
                <p>Home / Shoes</p>
                <h1>Flat Lace Fastening Shoes</h1>
                <h4 id="product-price" data-price="48.00">$48.00</h4>

                <!-- Add to Cart Form -->
                <form id="add-to-cart-form">
                    <input type="hidden" name="product_image" value="images/product-10.jpg">
                    <input type="hidden" name="product_base_price" value="48.00">

                    <label for="size">Select Size:</label>
                    <select name="product_size" id="size" required>
                        <option value="Small">Small</option>
                        <option value="Medium">Medium</option>
                        <option value="Large">Large</option>
                    </select>

                    <label for="quantity">Quantity:</label>
                    <input type="number" name="product_quantity" id="quantity" value="1" min="1" required>
                    
                    <label>Total Price:</label>
                    <span id="total-price">$48.00</span>

                    <button type="submit">Add to Cart</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        const quantityInput = document.getElementById('quantity');
        const priceElement = document.getElementById('product-price');
        const totalPriceElement = document.getElementById('total-price');

        quantityInput.addEventListener('input', () => {
            const basePrice = parseFloat(priceElement.dataset.price);
            const quantity = parseInt(quantityInput.value, 10);
            const totalPrice = basePrice * (quantity > 0 ? quantity : 1);
            totalPriceElement.textContent = `$${totalPrice.toFixed(2)}`;
        });

        // Handle form submission via AJAX
        document.getElementById('add-to-cart-form').addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);

            fetch('flat-lace-fastening-shoes_insertdata.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Product Added',
                        text: 'Product added to the cart successfully!',
                    }).then(() => window.location.href = 'add_to_cart_show_data.php');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message || 'Failed to add product to the cart.',
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An unexpected error occurred. Please try again.',
                });
            });
        });
    </script>
    <style>
        body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
}

.container {
    width: 80%;
    margin: auto;
    overflow: hidden;
}

.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 0;
}

.logo img {
    width: 125px;
}

.small-container {
    max-width: 1080px;
    margin: auto;
    padding: 20px;
}

.single-product .row {
    display: flex;
    align-items: center;
}

.single-product .col-2 img {
    max-width: 100%;
}

form label {
    display: block;
    margin: 10px 0 5px;
}

form input, form select, form button {
    padding: 10px;
    width: 100%;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

    </style>
</body>

</html>
