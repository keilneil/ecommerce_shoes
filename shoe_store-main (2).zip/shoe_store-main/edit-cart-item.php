<?php
// Get the product details from the URL parameters
$productId = $_GET['id'];
$productQuantity = $_GET['quantity'];
$productSize = $_GET['size'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Cart Item</title>
</head>
<body>
    <h1>Edit Cart Item</h1>
    <form action="update-cart-item.php" method="post">
        <input type="hidden" name="product_id" value="<?= htmlspecialchars($productId) ?>">
        <label for="product_quantity">Quantity:</label>
        <input type="number" name="product_quantity" id="product_quantity" value="<?= htmlspecialchars($productQuantity) ?>" min="1" required>
        <br>
        <label for="product_size">Size:</label>
        <input type="text" name="product_size" id="product_size" value="<?= htmlspecialchars($productSize) ?>" required>
        <br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
