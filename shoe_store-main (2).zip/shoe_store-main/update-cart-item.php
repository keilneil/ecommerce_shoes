<?php
/**
 * Update cart item quantity and size.
 */

header('Content-Type: application/json');
require 'database-ecommerce/ecommerce_sql.php';

function updateCartItem($conn, $id, $quantity, $size) {
    $stmt = $conn->prepare("UPDATE cart SET product_quantity = ?, product_size = ? WHERE id = ?");
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("isi", $quantity, $size, $id);
    try {
        return $stmt->execute();
    } catch (Exception $e) {
        return false;
    } finally {
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
$quantity = filter_var($_POST['quantity'], FILTER_VALIDATE_INT);
$size = trim(htmlspecialchars($_POST['size']));

if (!$id || !$quantity || !$size) {
    echo json_encode(['success' => false, 'message' => 'Invalid or missing parameters.']);
    exit;
}

try {
    if (updateCartItem($conn, $id, $quantity, $size)) {
        echo json_encode(['success' => true, 'message' => 'Product details updated successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update product details.']);
    }
    $conn->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
